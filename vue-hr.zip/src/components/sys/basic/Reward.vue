<template>
    
</template>

<script>
    export default {
        name: "Reward"
    }
</script>

<style scoped>

</style>