<template>
    
</template>

<script>
    export default {
        name: "Department"
    }
</script>

<style scoped>

</style>