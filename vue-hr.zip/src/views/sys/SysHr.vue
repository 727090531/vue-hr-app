<template>
    <div>操作员管理</div>
</template>

<script>
    export default {
        name: "SysHr"
    }
</script>

<style scoped>

</style>