<template>
    <dvi>员工资料</dvi>
</template>

<script>
    export default {
        name: "PerEmp"
    }
</script>

<style scoped>

</style>