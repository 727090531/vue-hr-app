<template>
    <div>员工账套设置</div>
</template>

<script>
    export default {
        name: "SalSobCfg"
    }
</script>

<style scoped>

</style>