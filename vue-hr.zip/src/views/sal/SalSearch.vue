<template>
    <div>工资表查询</div>
</template>

<script>
    export default {
        name: "SalSearch"
    }
</script>

<style scoped>

</style>