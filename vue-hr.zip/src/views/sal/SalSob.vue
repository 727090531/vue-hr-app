<template>
    <div>工资账套管理</div>
</template>

<script>
    export default {
        name: "SalSob"
    }
</script>

<style scoped>

</style>